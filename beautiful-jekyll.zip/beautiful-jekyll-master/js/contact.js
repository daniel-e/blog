$("#contact-btn").click(function() {
  alert("See, JavaScript works! Did you not trust me?");
});